module.exports = function (msg) {
  console.log(msg)
}
